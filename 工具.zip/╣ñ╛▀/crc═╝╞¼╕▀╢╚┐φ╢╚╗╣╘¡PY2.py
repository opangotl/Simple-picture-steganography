# -*- coding: utf-8 -*-
import binascii
import struct
#\x49\x48\x44\x52\x00\x00\x01\xF4\x00\x00\x01\xA4\x08\x06\x00\x00\x00
#还原高度
#这里是图片的CRC
crc32key = 0xFC082FB8
for i in range(0, 4096):
  width = struct.pack('>i', i)
  for j in range(0, 4096):
    height = struct.pack('>i', j)
    data = '\x49\x48\x44\x52' + width + height +'\x08\x03\x00\x00\x00'#这里是chunkdata的五个字节
    crc32result = binascii.crc32(data) & 0xffffffff
    if crc32result == crc32key:
        print ''.join(map(lambda c: "%02X" % ord(c), width))
        print ''.join(map(lambda c: "%02X" % ord(c), height))